# -*- coding: utf-8 -*-

from rsa._compat import have_python3

if have_python3:
    from py3kconstants import *
else:
    from py2kconstants import *

